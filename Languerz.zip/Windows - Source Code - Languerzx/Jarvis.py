import speech_recognition as sr
import pyttsx3 as pt
import webbrowser
import os
import pywhatkit
import wikipedia
import datetime

engine = pt.init("sapi5")
v = engine.getProperty("voices")
engine.setProperty("voice", v[0].id)

time = datetime.datetime.now().hour

def speak(text):
    """
    Speaks the given text

    :param text: Text to speak
    """
    engine.say(text)
    engine.runAndWait()


if time < 24 and time < 13:
    print("Good Morning Sir.")
    speak("Good Morning Sir.")
    speak("Your AI-Assistant here sir.")
elif time > 13 and time < 18:
    print("Good Afternoon Sir.")
    speak("Good Afternoon Sir.")
    speak("Your AI-Assistant here sir.")
else:
    print("Good Evening Sir.")
    speak("Good Evening Sir.")
    speak("Your AI-Assistant here sir.")

def takeCommand():
    """
    Takes the command from the user and recognizes the command and returns the recognized command.
    """
    recog = sr.Recognizer()

    with sr.Microphone() as source:
        print("Listening...")
        speak("Listening")
        spech = recog.listen(source)
        reg = str(recog.recognize_google(spech))
        return reg
try:
    while True:
        com = takeCommand()
        command = com.lower()

        if "play music" in command:
            music = command.replace("play music", "")
            print(f"Sir, Playing music {music}")
            speak(f"Sir, Playing music {music}")
            pywhatkit.playonyt(music)

        elif "wikipedia" in command:
            wiki = command.replace("wikipedia", "")

            print(f"Searching {wiki} in wikipedia...")
            speak(f"Searching {wiki} in wikipedia")
            results = wikipedia.summary(wiki)
            print(results)
            speak(results)

        elif "now you can rest jarvis" in command:
            speak("Have a nice day sir.")
            speak("bye")
            break

        elif "open" in command:
            openweb = command.replace("open", "")
            webbrowser.open(openweb)

        elif "run system command" in command:
            command.replace("run system command", "")
            syscom = input("Enter the command sir:\n")
            output = os.system(syscom)
            print("Done Sir.")
            speak("Done Sir.")

        elif "make file" in command:
            path = input("Sir please, Enter the path of the file:\n")
            with open(path, "a") as file:
                content = input("Enter the content sir:\n")
                file.write(content)

except sr.exceptions.UnknownValueError as e:
    speak("Bye Sir.")