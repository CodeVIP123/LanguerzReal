import sys


with open(sys.argv[1], "r") as r:
    read = r.read()
    try:
        if "plusaint*" in read:
            read = read.replace("plusaint*", "+")
        if "subtrAint*" in read:
            read = read.replace("subtrAint*", "-")
        if "dividedsA*" in read:
            read = read.replace("dividedsA*", "/")
           
        exec(read)
        
    except SyntaxError as se:
        import dbms_main
        dbms_main.execute(read)


#with open("test.lz", "r") as r: