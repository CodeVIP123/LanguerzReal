with open("C:\\Windows - Source Code - Languerzx\\Languerzx.fls", "r") as f:
    code = f.read()

with open("Interpreter.py", "a") as fb:
    fb.write(code)